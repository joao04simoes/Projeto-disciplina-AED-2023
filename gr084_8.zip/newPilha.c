#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "tileblaster.h"

/*****************************************************************************
 * createStack()
 *
 * Arguments: matrix
 *            capacity
 *                 
 * Returns: stack
 *
 * Description: função que cria uma pilha com uma capacidade definida pelo 
 *              utilizador. A pilha será utilizada para armazenar matrizes
 *                                  
 ****************************************************************************/
Stack *createStack(unsigned capacity, Matriz *matrix)
{
    Stack *stack = (Stack *)malloc(sizeof(Stack));
    stack->capacity = capacity;
    /* unused so far */
    stack->top = -1;
    stack->array = (Matriz **)malloc((stack->capacity) * sizeof(Matriz *));
    
    for (int i = 0; i < stack->capacity; i++)
    {
        stack->array[i] = iniciarMatrix(matrix, stack->array[i]);
    }

    return stack;
}

/*****************************************************************************
 * isFulll()
 *
 * Arguments: stack
 *                 
 * Returns: stack->top
 *
 * Description: função que indica se a pilha está cheia, a pilha está cheia
 *              se o stack->top for igual a stack->capacity-1
 *             
 *                                   
 ****************************************************************************/
int isFull(Stack *stack)
{
    return stack->top == stack->capacity - 1;
}


/*****************************************************************************
 * isEmpty_dfs()
 * 
 * Arguments: stack
 *                 
 * Returns: stack->top
 *
 * Description: função que indica se a pilha está vazia, se estiver retorna -1
 *                    
 ****************************************************************************/
int isEmpty_dfs(Stack *stack)
{
    return stack->top == -1;
}

/*****************************************************************************
 * push_dfs()
 *
 * Arguments: matrix
 *            stack
 *                 
 * Returns: void
 *
 * Description: Incrementa o número de elementos da pilha e faz uma cópia da 
 *              matriz que recebe como argumento para o último elemento da 
 *              pilha. 
 *              
 *                                   
 ****************************************************************************/
void push_dfs(Stack *stack, Matriz *matrix)
{
    int i = ++stack->top;
    matrix = copyMatrix(matrix, stack->array[i]);

    return;
}


/* Function to remove an item from stack.  It decreases top by 1 */
/*****************************************************************************
 * pop_dfs()
 *
 * Arguments: matrix
 *            stack
 *                 
 * Returns: matrix
 *
 * Description: Começa por verificar se a pilha se encontra vazia, se esse for
 *              o caso dá "return NULL". Se a pilha não estiver vazia decrementamos
 *              o número de elementos que esta contém e fazemos uma cópia do último
 *              elemento para a matriz. Voltamos ao tabuleiro antes da última jogada.
 *                                        
 ****************************************************************************/
Matriz *pop_dfs(Stack *stack, Matriz *matrix)
{

    //nothing to return if it is empty
    if (isEmpty_dfs(stack))
        return NULL;
    int i = stack->top--;
    matrix = copyMatrix(stack->array[i], matrix);

    return matrix;
}


/*****************************************************************************
 * deleteStack()
 *
 * Arguments: stack
 *                 
 * Returns: void
 *
 * Description: Função que elimina todos os elementos presentes da pilha e 
 *              a própria pilha.
 *                                                 
 ****************************************************************************/
void deleteStack(Stack *stack)
{
    for (int i = 0; i < stack->capacity; i++)
    {
        freeMatriz(stack->array[i]);
    }
    free(stack->array);
    free(stack);

    return;
}