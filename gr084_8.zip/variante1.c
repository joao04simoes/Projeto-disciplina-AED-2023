#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "tileblaster.h"

// função de encontrar as coordenadas e chama a função de procurar a mancha
/*****************************************************************************
 * variante1()
 *
 * Arguments: matrix
 *                 
 * Returns: matrix
 *
 * Description: chama as funções necessárias para resolver a variante 1.
 *                                   
 ****************************************************************************/
Matriz *variante1(Matriz *matrix)
{
    Node *coluna = matrix->tail;
    int indice = matrix->rows - 1;
    int nColuna = matrix->colu;
    int flag = 0;
    int cor = 0;
    matrix->pontSpot = 0;

    while (coluna != NULL && indice >= 0)
    {
        flag = 0;
        if (coluna->data[indice] != -1)
        {
            cor = coluna->data[indice];
            coluna->data[indice] = -1;
            matrix->pontSpot++;

            if ((flag = procurarMancha(coluna, coluna, indice, cor, matrix)) == 1) // verifica se existe mancha na coordenada
            {

                matrix = createSpotList(matrix, indice, nColuna);
                matrix = eliminateSpot(matrix);
                matrix = GravidadeVertical(matrix);
                matrix = GravidadeHorizontal(matrix);

                coluna = matrix->tail;
                nColuna = matrix->colu;
                indice = matrix->rows - 1;
                continue;
            }
            else
            {

                coluna->data[indice] = cor;
                matrix->pontSpot--;
            }
        }
        if (indice > 0)
        {
            indice--;
        }
        else
        {

            if (nColuna == 0 && indice == 0)
            {
                return matrix;
            }

            coluna = coluna->prev;
            nColuna--;
            indice = matrix->rows - 1;
        }
    }
    return matrix;
}


/*****************************************************************************
 * procurarMancha()
 *
 * Arguments: ptr - coluna da matriz onde estamos a fazer a procura
 *            ptrVer - coluna da matriz onde estao indicadas as manchas
 *            indice 
 *            cor          
 *            matrix 
 * 
 * Returns: flag - int que indica se foi encontrada mancha ou não
 *
 * Description: Tenta encontrar a cor igual à do bloco selecionado , nos blocos adjacentes
 *              a este. Se sim returna 1 se não retorna 0.
 *                                   
 ****************************************************************************/
int procurarMancha(Node *ptr, Node *ptrVer, int indice, int cor, Matriz *matrix)
{

    int flag = 0;

    if (indice > 0 && cor == ptrVer->data[indice - 1]) // procura mancha no azulejo de cima
    {

        ptr->data[indice - 1] = -1;
        ptrVer->data[indice - 1] = -1;
        matrix->pontSpot++;
        flag = 1;
        procurarMancha(ptr, ptrVer, indice - 1, cor, matrix); // coloca na pilha a coordenada
    }

    if (indice < matrix->rows - 1 && cor == ptrVer->data[indice + 1]) // procura mancha no azulejo baixo
    {

        ptr->data[indice + 1] = -1;
        ptrVer->data[indice + 1] = -1;
        matrix->pontSpot++;
        flag = 1;
        procurarMancha(ptr, ptrVer, indice + 1, cor, matrix); // coloca na pilha a coordenada
    }

    if (ptr != matrix->head && cor == ptrVer->prev->data[indice]) // procura mancha no azulejo do lado esquerdo
    {

        ptr->prev->data[indice] = -1;
        ptrVer->prev->data[indice] = -1;
        matrix->pontSpot++;
        flag = 1;
        procurarMancha(ptr->prev, ptrVer->prev, indice, cor, matrix); // coloca na pilha a coordenada
    }

    if (ptr->next != NULL && cor == ptrVer->next->data[indice]) // procura mancha no azulejo do lado direito
    {

        ptr->next->data[indice] = -1;
        ptrVer->next->data[indice] = -1;
        matrix->pontSpot++;
        flag = 1;
        procurarMancha(ptr->next, ptrVer->next, indice, cor, matrix); // coloca na pilha a coordenada
    }

    return flag;
}


/*****************************************************************************
 * createSpotList()
 *
 * Arguments: matrix
 *            cordX
 *            cordY
 *                 
 * Returns: matrix
 *
 * Description: Cria uma lista com as manchas que encontramos
 *                                   
 ****************************************************************************/
Matriz *createSpotList(Matriz *matrix, int cordX, int cordY)
{
    spot *newSpot = (spot *)malloc(sizeof(spot));

    if (matrix->spotTail == NULL)
    {
        matrix->spotTail = newSpot;
        matrix->spotHead = newSpot;
        matrix->spotTail->prev = NULL;
        matrix->spotHead->cordX = matrix->rows - cordX;
        matrix->spotHead->cordY = cordY;
        matrix->spotHead->next = NULL;
        matrix->spotTail->next = NULL;
        matrix->n_plays++;
        return matrix;
    }

    newSpot->next = matrix->spotHead;
    matrix->spotHead->prev = newSpot;
    matrix->spotHead = newSpot;
    matrix->spotHead->cordX = matrix->rows - cordX;
    matrix->spotHead->cordY = cordY;
    matrix->n_plays++;
    return matrix;
}

/*****************************************************************************
 * eliminaSpot()
 *
 * Arguments: matrix
 *                 
 * Returns: matrix
 *
 * Description: Aumenta a pontuação, somando o valor da mancha eliminada
 *                                   
 ****************************************************************************/
Matriz *eliminateSpot(Matriz *matrix)
{
    
    matrix->pont = matrix->pont + (matrix->pontSpot * (matrix->pontSpot - 1));
    matrix->pontSpot = 0;
    return matrix;
}

