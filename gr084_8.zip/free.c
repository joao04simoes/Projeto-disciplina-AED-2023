#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "tileblaster.h"

/*****************************************************************************
 * freeMatriz()
 *
 * Arguments: matrix - matriz que vai ser eliminada
 *                 
 * Returns: void
 *
 * Description: Limpa o vetor de dados presente em cada nó da matriz e de seguida
 *              o nó em que o vetor se encontrava.
 *                        
 ****************************************************************************/
void freeMatriz(Matriz *matrix)
{

    Node *aux = matrix->head;

    while (aux != NULL)
    {

        free(matrix->head->data); // free do vetor de dados
        aux = matrix->head->next;
        free(matrix->head); // free do no da lista
        matrix->head = aux;
    }
    free(matrix);
    return;
}

/*****************************************************************************
 * free_spotlist()
 *
 * Arguments: matrix
 *                 
 * Returns: void
 *
 * Description: Limpa a lista de manchas que eliminamos
 *             
 *                        
 ****************************************************************************/
void free_spotlist(Matriz *matrix)
{

    spot *aux = matrix->spotHead;
    while (matrix->spotHead != NULL)
    {
        aux = matrix->spotHead->next;
        free(matrix->spotHead);
        matrix->spotHead = aux;
    }
    return;
}

/*****************************************************************************
 * free_maxSpot()
 *
 * Arguments: matrix
 *                 
 * Returns: void
 *
 * Description: Limpa a lista das manchas eliminadas para obter a pontuação
 *              máxima na variante 3
 *                       
 ****************************************************************************/
void free_maxSpot(Matriz *matrix)
{

    spot *aux = matrix->maxSpot;
    for (int i = 0; i < matrix->maxPlays; i++)
    {

        aux = matrix->maxSpot->prev;
        free(matrix->maxSpot);
        matrix->maxSpot = aux;
    }
    return;
}