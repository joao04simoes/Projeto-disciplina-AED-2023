#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "tileblaster.h"

/*****************************************************************************
 * read_file()
 *
 * Arguments: filename - nome do ficheiro de entrada
 * 			  fp
 * 			  firstline
 *            
 * Returns: matrix
 *
 * Description: Faz a leitura do ficheiro de entrada e preenche com a sua informação
 * 				a nossa matriz inicial.
 *                                          
 ****************************************************************************/
Matriz *read_file(const char *filename, FILE *fp, int firstLine)
{

	Matriz *matrix = (Matriz *)malloc(sizeof(Matriz));

	char buffer[5000]; // Buffer to read lines from the file

	matrix->rows = firstLine;

	if (fscanf(fp, "%d", &matrix->colu) == 1)
		;

	if (fscanf(fp, "%d", &matrix->variante) == 1)
		;
	matrix->head = NULL;
	matrix->tail = NULL;
	matrix->pontSpot = 0;
	matrix->pont = 0;
	matrix->n_plays = 0;
	matrix->maxPont = 0;
	matrix->spotTail = NULL;
	matrix->spotHead = NULL;
	matrix->done = false;
	if (matrix->variante < -3 || matrix->variante == -2){
		return matrix;
	}

	matrix = initMatrix(matrix);
	int indice = 0;
	int elementos = matrix->rows * matrix->colu;
	Node *coluna = matrix->head;
	int lidos = 0;
	while (fgets(buffer, sizeof(buffer), fp) != NULL && lidos != elementos) // le uma linha e guarda os valores na matriz
	{

		char *token = strtok(buffer, " ");
		while (token != NULL)
		{
			if (strcmp(token, "\n") == 0)
			{
				token = NULL;
				continue;
			}

			lidos++;
			escreveMatriz(matrix, &coluna, &indice, atoi(token));
			token = strtok(NULL, " ");
		}
	}
	return matrix;
}


/*****************************************************************************
 * initMatrix()
 *
 * Arguments: matrix
 *                 
 * Returns: matrix
 *
 * Description: Inicializa a matriz.
 *          
 *                                   
 ****************************************************************************/
Matriz *initMatrix(Matriz *matrix)
{

	for (int i = 0; i < matrix->colu; i++)
	{

		Node *newNode = (Node *)malloc(sizeof(Node));
		if (newNode == NULL)
		{
			exit(0);
		}

		// aloca memoria para o vetor de inteiros
		newNode->data = (int *)malloc(sizeof(int) * matrix->rows);
		if (!newNode->data)
		{
			exit(0);
		}
		newNode->next = NULL;
		newNode->prev = NULL;
		

		// coloca o novo nó na lista
		if (matrix->head == NULL)
		{
			matrix->head = newNode;
			matrix->tail = newNode;
			newNode->next = NULL;
			newNode->prev = NULL;
			continue;
		}
		Node *auxT = NULL;

		auxT = matrix->tail;
		matrix->tail = newNode;
		auxT->next = newNode;
		newNode->prev = auxT;

	
	}
	return matrix;
}

// escreve na matriz a cor do azulejo
/*****************************************************************************
 * escreveMatriz()
 *
 * Arguments: matrix
 * 			  coluna
 * 			  indice - posição na coluna da matriz
 * 			  cor
 *                 
 * Returns: void
 *
 * Description: Escreve a cor do azulejo passado como argumento no indice da coluna
 * 				da matrix 
 *                                            
 ****************************************************************************/
void escreveMatriz(Matriz *matrix, Node **coluna, int *indice, int cor)
{
	(*coluna)->data[*indice] = cor; // guarda a cor na matriz
	*coluna = (*coluna)->next;
	if (*coluna == NULL) // se estiver na ultima coluna volta ao inicio e incrementa o indice do vetor para a proxima linha
	{
		*coluna = matrix->head;
		(*indice)++;
	}

	return;
}
