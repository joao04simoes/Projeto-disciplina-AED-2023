#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "tileblaster.h"


/*****************************************************************************
 * fill_list()
 *
 * Arguments: lista
 *            newmatrix
 *                 
 * Returns: lista
 *
 * Description: Preenche a lista que contem em cada elemento uma das cores presentes
 *              na nossa matriz inicial, sempre que encontra uma cor ao percorrer a matriz
 *              verifica se esta já existe na lista, se sim incrementa o número de 
 *              de azulejos dessa cor, se for uma cor nova, cria um novo nó e incrementa
 *              o número de azulejos dessa cor
 *                         
 ****************************************************************************/
lista_manchas *fill_list(Matriz *newmatrix, lista_manchas *lista)
{
    Node *aux = newmatrix->head;
    lista->n_cores = 0;

    while (aux != NULL)
    {
        for (int i = newmatrix->rows - 1; i >= 0; i--)
        {
            if (aux->data[i] != -1)
            {
                No *auxL = lista->head;
                int colorExists = 0;

                while (auxL != NULL)
                {
                    if (auxL->cor == aux->data[i])
                    {
                        colorExists = 1;
                        auxL->count++;
                        break;
                    }
                    auxL = auxL->next;
                }

                if (colorExists == 0)
                {
                    No *newNode = novo_no(lista);
                    newNode->cor = aux->data[i];
                    newNode->count++;
                    lista->n_cores++;
                }
            }
        }
        aux = aux->next;
    }

    return lista;
}

/*****************************************************************************
 * thereishope_2()
 *
 * Arguments: filename
 *            newmatrix
 *            cor
 *                 
 * Returns: bond - flag que indica se a jogada é válida ou nao
 *
 * Description: Verifica se a jogada que queremos fazer resulta numa solução
 *              que nos permita chegar ao resultado pretendido.
 *              Usada na variante 2 do projeto
 *                                            
 ****************************************************************************/
int thereishope_2(Matriz *newmatrix, lista_manchas *lista, int cor)
{

    No *auxL = lista->head;
    int bond = 0;

    while (auxL != NULL)
    {

        if (auxL->cor == cor)
        {

            auxL->count = auxL->count - newmatrix->pontSpot;
            lista->max = calcula_max(lista);

            if ((lista->max + (newmatrix->pontSpot * (newmatrix->pontSpot - 1)) + newmatrix->pont) >= newmatrix->variante)
            {

                lista->max = lista->max - (newmatrix->pontSpot * (newmatrix->pontSpot - 1));
                bond = 1;
            }
            else
            {

                auxL->count = auxL->count + newmatrix->pontSpot;

                bond = 0;
            }
            return bond;
        }
        auxL = auxL->next;
    }
    return bond;
}


/*****************************************************************************
 * thereishope_3()
 *
 * Arguments: newmatrix
 *            lista
 *            cor
 *            maxPont
 *                 
 * Returns: bond - flag que indica se a jogada é válida ou nao
 *
 * Description: Verifica se a jogada que queremos fazer resulta numa solução
 *              que nos permita chegar ao resultado pretendido.
 *              Usada na variante 3 do projeto.
 *                                   
 ****************************************************************************/
int thereishope_3(Matriz *newmatrix, lista_manchas *lista, int cor, int maxPont)
{
    No *auxL = lista->head;
    int bond = 0;

    while (auxL != NULL)
    {

        if (auxL->cor == cor)
        {

            auxL->count = auxL->count - newmatrix->pontSpot;
            lista->max = calcula_max(lista);

            if ((lista->max + (newmatrix->pontSpot * (newmatrix->pontSpot - 1)) + newmatrix->pont) > maxPont)
            {

                lista->max = lista->max - (newmatrix->pontSpot * (newmatrix->pontSpot - 1));
                bond = 1;
            }
            else
            {
                auxL->count = auxL->count + newmatrix->pontSpot;

                bond = 0;
            }
            return bond;
        }
        auxL = auxL->next;
    }
    return bond;
}

/*****************************************************************************
 * add_tiles()
 *
 * Arguments: size
 *            lista
 *            cor
 *                      
 * Returns: void
 *
 * Description: Percorre a lista das cores até encontrar o elemento com a cor
 *              correspondente à passada como argumento e incrementa o número
 *              de azulejos dessa cor. Isto é feito quando uma jogada foi 
 *              considerada inválida e queremos voltar à matriz antes dessa 
 *              modificação.          
 *                                   
 ****************************************************************************/
void add_tiles(int size, lista_manchas *lista, int cor)
{
    No *auxL = lista->head;
    while (auxL != NULL)
    {
        if (auxL->cor == cor)
        {
            auxL->count = auxL->count + size;
        }
        auxL = auxL->next;
    }
}

/*****************************************************************************
 * novo_no()
 *
 * Arguments: lista
 *                         
 * Returns: No
 *
 * Description: cria um novo nó na lista das cores
 *                                   
 ****************************************************************************/
No *novo_no(struct lista_manchas *lista)
{
    struct No *newNode = (struct No *)malloc(sizeof(struct No));
    No *aux;
    if (newNode == NULL)
    {

        exit(0);
    }
    newNode->cor = 0;
    newNode->count = 0;
    newNode->next = NULL;

    if (lista->head == NULL)
        lista->head = newNode;
    else
    {
        aux = lista->head;
        lista->head = newNode;
        lista->head->next = aux;
    }
    return newNode;
}

/*****************************************************************************
 * init_listam()
 *
 * Arguments: none
 *                 
 * Returns: lista
 *
 * Description: Inicializa a lista das cores
 *                                   
 ****************************************************************************/
lista_manchas *init_listam()
{
    lista_manchas *lista = (lista_manchas *)malloc(sizeof(lista_manchas));
    if (lista == NULL)
    {

        exit(0);
    }
    lista->head = NULL;
    return lista;
}

/*****************************************************************************
 * thereishope_3()
 *
 * Arguments: newmatrix
 *            lista
 *            cor
 *             maxPont
 *                 
 * Returns: bond - flag que indica se a jogada é válida ou nao
 *
 * Description: Cálcula a pontuação máxima obtida pelo melhor caso possivel, todos
 *              os elementos da lista das cores estarem juntos.
 *                                   
 ****************************************************************************/
int calcula_max(lista_manchas *lista)
{
    int max = 0;
    No *aux = lista->head;

    while (aux != NULL)
    {

        max = max + (aux->count * (aux->count - 1));
        aux = aux->next;
    }
    return max;
}

/*****************************************************************************
 * free_lista_manchas()
 *
 * Arguments: lista
 *                 
 * Returns: void
 *
 * Description: Elimina os nós da lista das corres e por fim elimina a própria lista
 *                                   
 ****************************************************************************/
void free_lista_manchas(lista_manchas *lista)
{
    No *current = lista->head;
    while (current != NULL)
    {
        No *temp = current;
        current = current->next;
        free(temp);
    }
    lista->head = NULL;
    free(lista);
}
